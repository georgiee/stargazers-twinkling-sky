var shootingStar = document.querySelector('.shooting-star');
function toggle() {
    shootingStar.classList.toggle('debug');
}